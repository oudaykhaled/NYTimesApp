package com.apps2you.b_app_repositories.network;

/**
 * Created by oudaykhaled on 12/5/17.
 */

public interface HttpListener {
    String onPreExecuting(String url);
    String onPostExecuting(String url, String response);
}
