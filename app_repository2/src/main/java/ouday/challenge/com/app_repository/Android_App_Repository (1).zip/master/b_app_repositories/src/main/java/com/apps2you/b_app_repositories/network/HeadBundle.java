package com.apps2you.b_app_repositories.network;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Created by AppsOuday on 9/18/2017.
 * Bundle to hold all HTTP Head Key-Value data
 */
public class HeadBundle {

    private HashMap<String, Object> hmHead = new HashMap<>();

    public void addBodyDetail(String key, String value){
        hmHead.put(key, value);
    }

    public void remove(String key){
        hmHead.remove(key);
    }

    public Set<Map.Entry<String, Object>> getIterator(){
        return hmHead.entrySet();
    }

}
