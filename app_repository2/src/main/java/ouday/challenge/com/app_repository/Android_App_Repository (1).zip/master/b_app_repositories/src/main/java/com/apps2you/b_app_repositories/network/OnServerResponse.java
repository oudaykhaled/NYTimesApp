package com.apps2you.b_app_repositories.network;

/**
 * Created by AppsOuday on 9/18/2017.
 * Contains all Call back for any HTTP Response
 */
public interface OnServerResponse<T> {
    void onSuccess(HttpController httpController, T response);
    void onFailed(HttpController httpController, Exception ex);
}
