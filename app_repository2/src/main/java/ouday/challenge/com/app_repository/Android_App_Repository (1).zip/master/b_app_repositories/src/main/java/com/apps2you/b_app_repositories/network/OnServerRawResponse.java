package com.apps2you.b_app_repositories.network;

/**
 * Created by AppsOuday on 9/18/2017.
 * Contains all Call back for any Raw HTTP Response
 */
public interface OnServerRawResponse {
    void onSuccess(HttpController httpController, String response);
    void onFailed(HttpController httpController, Exception ex);
}
