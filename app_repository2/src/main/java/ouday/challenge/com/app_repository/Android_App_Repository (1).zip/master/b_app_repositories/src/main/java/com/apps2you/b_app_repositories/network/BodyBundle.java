package com.apps2you.b_app_repositories.network;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Created by AppsOuday on 9/18/2017.
 * Bundle to hold all HTTP Body Key-Value data
 */
public class BodyBundle {
    private HashMap<String, Object> hmBody = new HashMap<>();

    public void addBodyDetail(String key, String value){
        hmBody.put(key, value);
    }

    public void remove(String key){
        hmBody.remove(key);
    }

    public Set<Map.Entry<String, Object>> getIterator(){
        return hmBody.entrySet();
    }
}
