package com.apps2you.b_app_repositories.location_provider;

/**
 * Created by AppsLayale on 11/16/2017.
 */

public interface OnLocationReceived {
    void permissionRejected();
    void onProviderEnabled(String providerName);
    void onLocationChange(double longitude, double latitude, float accuracy, String provider);
    void onProviderDisabled(String providerName);

}
