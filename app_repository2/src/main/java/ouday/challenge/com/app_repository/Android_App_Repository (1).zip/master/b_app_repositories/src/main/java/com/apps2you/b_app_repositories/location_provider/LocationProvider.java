package com.apps2you.b_app_repositories.location_provider;

/**
 * Created by AppsLayale on 11/16/2017.
 */

public interface LocationProvider {
    void requestLocation(OnLocationReceived onLocationReceived);
}
